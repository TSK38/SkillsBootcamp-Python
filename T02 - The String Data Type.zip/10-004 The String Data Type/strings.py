# Pratical Task 1
# declaring a variable called hero
hero = "$$$Superman$$$"

# used the strip function to remove the $$$ 
print(hero.strip('$'))