'''This is the pseudo code to Practical Task 3
First set the following variables; num1 = 99.23, num2 = 23, num3 = 150 & string1 = "100"
Convert the variables as follows before printing them all out on separate lines; num1 into an integer, num2 into a float, num3 into a String and string1 into an integer'''

num1 = 99.23
num2 = 23
num3 = 150
string1 = "150"
print(int(num1))
print(float(num2))
print(str(num3))
print(int(string1))