'''This is the pseudo code to Practical Task 1
Ask the user to input their name and then print out the name
Use the same approach (input + print) to obtain and print the users age
At last, print the phrase "Hello World" on a new line'''

name = input("Please enter your name: ")
age = input("Please enter your age: ")
print("Hello World!")